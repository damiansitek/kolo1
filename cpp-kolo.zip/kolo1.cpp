// Damian  Sitek  grupa  Zsziad  101572


#include <iostream>
using namespace std;

int main(int argc, char **argv) {
  cout<<"I love git!"<<endl;
  return 0;
}

